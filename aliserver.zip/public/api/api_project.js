define({
  "name": "mymall-api",
  "version": "1.0.0",
  "description": "第一个全栈项目",
  "title": "mymall的接口文档",
  "header": {
    "title": "文档说明",
    "content": "<h5>这个网站是我的第一个网站，所有的建设都是新鲜的尝试，找了各种各样的教程，欢迎围观。</h5>\n"
  },
  "footer": {
    "title": "文档结尾",
    "content": "<h5>最后的最后，感谢大家的支持！</h5>\n"
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-03-08T07:48:40.511Z",
    "url": "https://apidocjs.com",
    "version": "0.26.0"
  }
});
