
const SECRET = 'apple-pineapple';//密钥

module.exports = SECRET;