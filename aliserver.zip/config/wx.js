let wx = {
    appid:"",//小程序ID，可以查询
    appScret:""//程序密钥
}

module.exports = wx;